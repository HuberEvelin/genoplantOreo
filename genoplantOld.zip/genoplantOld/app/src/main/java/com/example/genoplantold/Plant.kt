package com.example.genoplantold

class Plant {
    var Id:String = ""
        get() = field
        set(value){
            field=value
        }
    var Name : String = ""
        get() = field
        set(value){
            field=value
        }
    var Specie : String=""
        get() = field
        set(value){
            field=value
        }
    var Indoor : Boolean=false
        get() = field
        set(value){
            field=value
        }
    var Date : String=""
        get() = field
        set(value){
            field=value
        }
    var Soil: String=""
        get() = field
        set(value){
            field=value
        }
    var Fertilized: Boolean =false
        get() = field
        set(value){
            field=value
        }
    var AdditionalNote: String = ""
        get() = field
        set(value){
            field=value
        }
    var UploadDate: String =""
        get() = field
        set(value){
            field=value
        }
    var OwnerId: Int=0
        get() = field
        set(value){
            field=value
        }
    var LastModified: String =""
        get() = field
        set(value){
            field=value
        }
    var Temperature: Int=0
        get() = field
        set(value){
            field=value
        }
    var Humidity: Int=0
        get() = field
        set(value){
            field=value
        }


    constructor(
        Id: String,
        UploadDate: String,
        Name: String,
        Specie: String,
        Indoor: Boolean,
        Date: String,
        Soil: String,
        Fertilized: Boolean,
        AdditionalNote: String,
        ownerId: Int,
        LastModified: String,
        Temperature: Int,
        Humidity: Int
    ) {
        this.Id=Id
        this.Name = Name
        this.Specie = Specie
        this.Indoor = Indoor
        this.Date = Date
        this.Soil = Soil
        this.Fertilized = Fertilized
        this.AdditionalNote = AdditionalNote
        this.UploadDate=UploadDate
        this.OwnerId=ownerId
        this.LastModified=LastModified
        this.Temperature=Temperature
        this.Humidity=Humidity
    }
}
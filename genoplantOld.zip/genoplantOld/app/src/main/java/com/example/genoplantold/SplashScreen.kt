package com.example.genoplantold

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.RecyclerView

class SplashScreen : AppCompatActivity() {
    private lateinit var dbHelper: DatabaseHelper
    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: PlantNameAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        UserEmail.setUserId(0)
        UserEmail.setUserEmail("teszt@teszt.hu")
        super.onCreate(savedInstanceState)
        setContentView(R.layout.splash_screen)
        val handler = Handler(Looper.getMainLooper())
        handler.postDelayed(Runnable {
            val intent= Intent(this, PlantNameActivity::class.java)
            startActivity(intent)
        }, 1500)
    }
    override fun onBackPressed() {
        return
        super.onBackPressed()
    }
}
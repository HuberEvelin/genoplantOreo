package com.example.genoplantold

interface OnPlantClickListener {
    fun onPlantClick(position: Int)
}
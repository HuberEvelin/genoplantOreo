package com.example.genoplantold

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.net.Uri
import android.util.Log
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.async
import org.json.JSONObject
import java.io.BufferedReader
import java.io.DataOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

class DatabaseHelper(context: Context): SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {
    companion object {
        private const val DATABASE_VERSION = 1
        private const val DATABASE_NAME = "Plants.db"
    }


    override fun onCreate(db: SQLiteDatabase) {
        var createTableQuery = ("CREATE TABLE users (id INTEGER PRIMARY KEY, email TEXT)")
        db.execSQL(createTableQuery)
        createTableQuery = ("CREATE TABLE plants (id INTEGER PRIMARY KEY, owner_id INTEGER, name TEXT, date TEXT, specie TEXT, FOREIGN KEY(owner_id) REFERENCES users(id) ON DELETE CASCADE)")
        db.execSQL(createTableQuery)
        createTableQuery = ("CREATE TABLE plant_forms (id INTEGER PRIMARY KEY, plant_id INTEGER, upload_date TEXT, indoor INTEGER, soil TEXT, fertilized INTEGER, additional_note TEXT, temperature INTEGER, humidity INTEGER, last_modified TEXT, FOREIGN KEY(plant_id) REFERENCES plants(id) ON DELETE CASCADE)")
        db.execSQL(createTableQuery)
        createTableQuery = ("CREATE TABLE plant_images (form_id INTEGER, image_path TEXT PRIMARY KEY, FOREIGN KEY(form_id) REFERENCES plant_forms(id) ON DELETE CASCADE)")
        db.execSQL(createTableQuery)
    }


    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {

        db.execSQL("DROP TABLE IF EXISTS plant_images")
        db.execSQL("DROP TABLE IF EXISTS plant_forms")
        db.execSQL("DROP TABLE IF EXISTS plants")
        db.execSQL("DROP TABLE IF EXISTS users")
        onCreate(db)
    }

    override fun onConfigure(db: SQLiteDatabase) {
        super.onConfigure(db)
        db.setForeignKeyConstraintsEnabled(true)
    }

    fun insertPlantForm(plantId: Int, indoor: Int, soil: String, fertilized: Int, additionalNote: String, lastModified: String, Temperature: Int, Humidity: Int, imageList : ArrayList<String>) {
        val currentDateTime = LocalDateTime.now()

        val formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")
        val formattedDateTime = currentDateTime.format(formatter)
        val db = this.writableDatabase
        val contentValues = ContentValues()
        contentValues.put("plant_id", plantId)
        contentValues.put("upload_date", formattedDateTime)
        contentValues.put("last_modified", formattedDateTime)
        contentValues.put("indoor", indoor)
        contentValues.put("soil", soil)
        contentValues.put("fertilized", fertilized)
        contentValues.put("additional_note", additionalNote)
        contentValues.put("temperature", Temperature)
        contentValues.put("humidity", Humidity)
        db.insert("plant_forms", null, contentValues)
        db.close()
        for (image_path in imageList){
            insertDataToImages(getPropId(plantId, formattedDateTime), image_path)
            Log.d("ImageList", image_path)
        }
    }
    fun insertPlant(name: String, specie: String, uploadDate: String, ownerId: Int){
        if (checkPlantExists(ownerId, name) != -1) {
            val formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")
            val formattedDateTime = uploadDate.format(formatter)
            val db = this.writableDatabase
            val contentValues = ContentValues()
            contentValues.put("name", name)
            contentValues.put("date", formattedDateTime)
            contentValues.put("owner_id", ownerId)
            contentValues.put("specie", specie)
            db.insert("plants", null, contentValues)
            db.close()
        }
    }

    fun insertUser(email: String){
        val dbRead = this.readableDatabase
        val selection = "email = ?"
        val selectionArgs = arrayOf(email.toString())

        val cursor = dbRead.query(
            "users", // Tábla neve
            null,
            selection,
            selectionArgs,
            null,
            null,
            null
        )

        if (cursor ==null || cursor.count==0 ) {
            val dbWrite = this.writableDatabase
            val contentValues = ContentValues()
            contentValues.put("email", email)
            dbWrite.insert("users", null, contentValues)
            cursor.close()
            dbWrite.close()
        }
        dbRead.close()
    }

    fun selectPlantNameByName(name: String): String{
        val db = this.readableDatabase
        val selection = "name = ?"
        val selectionArgs = arrayOf(name)

        val cursor = db.query(
            "plants", // Tábla neve
            null,
            selection,
            selectionArgs,
            null,
            null,
            null
        )

        if (cursor !=null && cursor.moveToFirst() ) {
            val id=cursor.getString(0)
            cursor.close()
            db.close();
            return id
        }
        return ""
    }

    fun selectAllPlantNames(): ArrayList<Plant>{
        val dataList = ArrayList<Plant>()
        val db = this.readableDatabase
        val cursor = db.rawQuery("SELECT * FROM plants WHERE owner_id=${UserEmail.getUserId()}", null)
        cursor.moveToFirst()
        while (!cursor.isAfterLast) {
            dataList.add(
                Plant(
                    cursor.getString(0),
                    "",
                    cursor.getString(2),
                    cursor.getString(4),
                    false,
                    cursor.getString(3),
                    "",
                    false,
                    "",
                    ownerId = cursor.getInt(1),
                    "",
                    0,
                    0
                )
            )
            cursor.moveToNext()
        }
        cursor.close()
        db.close()
        Log.d("DBHelper", dataList.size.toString())
        return dataList
    }
    fun insertDataToImages(plantId: Int, image_path: String){
        val db = this.writableDatabase
        val contentValues = ContentValues()
        contentValues.put("form_id", plantId)
        contentValues.put("image_path", image_path)
        db.insert("plant_images", null, contentValues)
        db.close()
    }

    fun updateDataToImages(plantId: Int, image_path: String){
        val db = this.writableDatabase
        val contentValues = ContentValues()
        contentValues.put("image_path", image_path)
        db.update("plant_images",contentValues, "form_id=?", arrayOf(plantId.toString()))
        db.close()
    }

    fun getPropId(plant_id: Int, upload_date: String) : Int {
        val db = this.writableDatabase
        var upload_date_formatted = "'" + upload_date + "'"
        val cursor = db.rawQuery("SELECT pp.id FROM plant_forms pp WHERE pp.plant_id=$plant_id AND pp.upload_date=$upload_date_formatted", null)
        cursor.moveToFirst()
        val foundId = cursor.getInt(0)

        cursor.close()
        db.close()
        return foundId
    }

    fun checkPlantExists(ownerId: Int, plantName: String): Int {
        val db = this.readableDatabase

        val cursor = db.rawQuery("SELECT COUNT(*) FROM plants WHERE owner_id=$ownerId AND name='$plantName'", null)
        var result = -1

        cursor.use {
            if (it.moveToFirst()) {
                val count = it.getInt(0)
                result = if (count > 0) 0 else 1
            }
        }
        db.close()
        return result
    }

    fun updatePlantForm(id: String, indoor: Int, soil: String, fertilized: Int, additionalNote: String, Temperature: Int, Humidity: Int, imageList : ArrayList<String>) {
        val db = this.writableDatabase
        val contentValues = ContentValues()
        contentValues.put("indoor", indoor)
        contentValues.put("soil", soil)
        contentValues.put("fertilized", fertilized)
        contentValues.put("additional_note", additionalNote)
        contentValues.put("last_modified", LocalDateTime.now().toString())
        contentValues.put("temperature", Temperature)
        contentValues.put("humidity", Humidity)
        db.update("plant_forms", contentValues, "id = ?", arrayOf(id.toString()))
        db.close()
        if(imageList.size>0){
            for (image_path in imageList){
                insertDataToImages(id.toInt(), image_path)
            }
        }
    }
    fun deleteImageByPath(uri: Uri){
        val db = this.writableDatabase
        db.delete("plant_images", "image_path = ?", arrayOf(uri.path.toString()))
        db.close()
    }
    fun getUserId(email: String): Int{
        val db = this.readableDatabase
        val array= arrayOf(email)
        val cursor = db.rawQuery("SELECT id FROM users WHERE email = ? ", array)
        var id=-1
        if(cursor.moveToFirst())
            id=cursor.getInt(0)
        cursor.close()
        db.close()
        return id
    }

    fun getAllFromPlantPropertiesById(id: String): ArrayList<Plant> {
        val dataList = ArrayList<Plant>()
        val db = this.readableDatabase
        val cursor = db.rawQuery("SELECT pp.id, p.name, p.specie, pp.indoor, pp.upload_date, pp.soil, pp.fertilized, pp.additional_note, p.owner_id, pp.last_modified, pp.temperature, pp.humidity  FROM plant_forms pp INNER JOIN plants p On pp.plant_id=p.id WHERE pp.plant_id=$id", null)
        cursor.moveToFirst()
        while (!cursor.isAfterLast) {
            dataList.add(
                Plant(
                    cursor.getString(0),
                    cursor.getString(4),
                    cursor.getString(1),
                    cursor.getString(2),
                    cursor.getInt(3)==1,
                    cursor.getString(4),
                    cursor.getString(5),
                    cursor.getInt(6)==1,
                    cursor.getString(7),
                    cursor.getInt(8),
                    cursor.getString(9),
                    cursor.getInt(10),
                    cursor.getInt(11)
                )
            )
            cursor.moveToNext()
        }
        cursor.close()
        db.close()
        return dataList
    }

    fun getImagesByPlantFormId (plantFormId: Int): ArrayList<String>{
        val imagePaths = ArrayList<String>()
        val db = this.readableDatabase
        val cursor = db.rawQuery("SELECT image_path FROM plant_images WHERE form_id=?", arrayOf(plantFormId.toString()))
        cursor.moveToFirst()
        while (!cursor.isAfterLast) {
            imagePaths.add(
                cursor.getString(0)
            )
            cursor.moveToNext()
        }
        cursor.close()
        db.close()
        return imagePaths
    }

    suspend fun syncData () : String {
        val db = this.readableDatabase
        val cursor = db.rawQuery(" SELECT p.name, p.specie, p.date, pf.last_modified, pf.upload_date, pf.indoor, pf.soil, pf.fertilized, pf.additional_note, p.owner_id, pf.id FROM plants p LEFT JOIN plant_forms pf ON p.id = pf.plant_id WHERE p.owner_id = ${UserEmail.getUserId()}", null)
        val syncClass = SyncClass()

        if (cursor.moveToFirst()) {
            do {
                if (cursor.getString(3) != null) {
                    syncClass.email=UserEmail.getUserEmail()
                    println(syncClass.email)
                    syncClass.plant.Name = cursor.getString(0)
                    syncClass.plant.Specie = cursor.getString(1)
                    syncClass.plant.Date = cursor.getString(2)
                    syncClass.plant.LastModified = cursor.getString(3)
                    syncClass.plant.UploadDate = cursor.getString(4)
                    syncClass.plant.Indoor = cursor.getInt(5) != 0
                    syncClass.plant.Soil = cursor.getString(6)
                    syncClass.plant.Fertilized = cursor.getInt(7) != 0
                    syncClass.plant.AdditionalNote = cursor.getString(8)
                    syncClass.plant.OwnerId = cursor.getInt(9)

                    println(syncClass.plant.Name + ' ' + syncClass.plant.Indoor + syncClass.plant.Fertilized)

                    val images=getImagesByPlantFormId(cursor.getString(10).toInt())
                    val data = syncClass.toJsonString()
                    try{
                        val result = performNetworkRequest(data, images).await()
                        println("Network request result: $result")
                    }
                    catch(e: Exception){
                        return "There was an error while syncing"
                    }

                }

            } while (cursor.moveToNext())
        }
        cursor.close()
        return "Syncing was succesful!"
    }

    fun performNetworkRequest(json: JSONObject, images: List<String>): Deferred<String?> {
        return GlobalScope.async {
            var result: String? = null
            try {
                val url = URL("http://142.93.207.109/CameraMeta_Server/server.php")
                val conn = url.openConnection() as HttpURLConnection
                conn.requestMethod = "POST"
                conn.setRequestProperty("Content-Type", "multipart/form-data; boundary=*****")
                conn.doOutput = true

                val outputStream = DataOutputStream(conn.outputStream)

                // Add JSON data
                outputStream.writeBytes("--*****\r\n")
                outputStream.writeBytes("Content-Disposition: form-data; name=\"json\"\r\n\r\n")
                outputStream.write(json.toString().toByteArray(Charsets.UTF_8))
                outputStream.writeBytes("\r\n")

                // Add images
                images.forEachIndexed { index, imagePath ->
                    val imageFile = File(imagePath)
                    val fileName = imageFile.name
                    val lineEnd = "\r\n"

                    outputStream.writeBytes("--*****\r\n")
                    outputStream.writeBytes("Content-Disposition: form-data; name=\"image_$index\";filename=\"$fileName\"\r\n")
                    outputStream.writeBytes("Content-Type: image/jpeg\r\n\r\n")

                    val fileInputStream = FileInputStream(imageFile)
                    val buffer = ByteArray(1024)
                    var bytesRead: Int

                    while (fileInputStream.read(buffer).also { bytesRead = it } != -1) {
                        outputStream.write(buffer, 0, bytesRead)
                    }

                    outputStream.writeBytes(lineEnd)
                    outputStream.writeBytes("--*****--\r\n")
                    fileInputStream.close()
                }

                outputStream.flush()
                outputStream.close()

                val responseCode = conn.responseCode
                println("Response Code: $responseCode")

                if (responseCode == HttpURLConnection.HTTP_OK) {
                    val response = BufferedReader(InputStreamReader(conn.inputStream, Charsets.UTF_8))
                    var inputLine: String?
                    val responseContent = StringBuffer()

                    while (response.readLine().also { inputLine = it } != null) {
                        responseContent.append(inputLine)
                    }
                    response.close()

                    result = responseContent.toString()
                } else {
                    result = "Error: $responseCode"
                }

                conn.disconnect()

            } catch (e: Exception) {
                e.printStackTrace()
                result = "Error: ${e.message}"
            }
            result
        }
    }

    fun deletePlantById(id: Int) {
        val db = writableDatabase
        db.beginTransaction()
        try {
            // Töröljük a rekordot a plants táblából az id alapján
            db.delete("plants", "id = ?", arrayOf(id.toString()))
            // Sikeres tranzakció
            db.setTransactionSuccessful()
        } catch (e: Exception) {
            Log.e("deletePlant", "Error while trying to delete plant by id", e)
        } finally {
            // Zárjuk le a tranzakciót
            db.endTransaction()
        }
    }

    fun deletePlantFormById(formId: String) {
        val images=getImagesByPlantFormId(formId.toInt())
        for(image in images){
            var file=File(image.toString())
            file.delete()
        }
        val db = writableDatabase
        db.beginTransaction()
        try {
            db.delete("plant_forms", "id = ?", arrayOf(formId.toString()))
            db.setTransactionSuccessful()
        } catch (e: Exception) {
            Log.e("DeleteForm", "Error while trying to delete plant form by id", e)
        } finally {
            db.endTransaction()
        }
    }
}
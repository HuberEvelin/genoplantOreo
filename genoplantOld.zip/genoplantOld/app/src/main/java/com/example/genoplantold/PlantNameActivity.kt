package com.example.genoplantold

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import android.content.Intent
import android.net.ConnectivityManager
import android.widget.Button
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.genoplantold.UserEmail.Companion.getUserEmail
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.material.floatingactionbutton.FloatingActionButton
//import com.google.firebase.Firebase
//import com.google.firebase.auth.FirebaseAuth
//import com.google.firebase.auth.auth
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class PlantNameActivity : AppCompatActivity() {
    private lateinit var dbHelper: DatabaseHelper
    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: PlantNameAdapter
    private lateinit var mGoogleSignInClient: GoogleSignInAccount
    //private lateinit var mAuth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_plant_name)
        val GoToPlantProperties = Intent(this, PlantPropertiesActivity::class.java)

        //mAuth = FirebaseAuth.getInstance()


        /*val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestIdToken("884610481366-70olpheu6di0j5ppcb2pd5m7ajc6vi58.apps.googleusercontent.com")
            .requestEmail()
            .build()

         */

        //mGoogleSignInClient = GoogleSignInAccount.(this, gso)

        //val auth = Firebase.auth
        //val user = auth.currentUser
        dbHelper = DatabaseHelper(this)

        /*if (user == null) {
            val backToSignInActivity = Intent(this, SignInActivity::class.java)
            startActivity(backToSignInActivity)
        }
        else{
            UserEmail.setUserEmail(user.email.toString())
            UserEmail.setUserId(dbHelper.getUserId(user.email.toString()))
        }
        */


        val dataList =dbHelper.selectAllPlantNames()
        if(dataList.size==0){
            setContentView(R.layout.activity_main_empty)
        }
        else{
            adapter = PlantNameAdapter(object : OnPlantClickListener {
                override fun onPlantClick(position: Int) {

                    val clickedPlant = dataList[position]
                    GoToPlantProperties.putExtra("Name", clickedPlant.Name)
                    GoToPlantProperties.putExtra("Id", clickedPlant.Id.toInt())
                    startActivity(GoToPlantProperties)
                }
            })
            recyclerView = findViewById(R.id.allPlantsRecycleView)
            recyclerView.adapter = adapter
            recyclerView.layoutManager = LinearLayoutManager(this)
            adapter.submitList(dataList)
        }
        //val deleteButton = findViewById<Button>(R.id.deletePlantButton)
        val sign_out_button = findViewById<Button>(R.id.logout_button)
        /*sign_out_button.setOnClickListener {
            signOutAndStartSignInActivity()
        }*/

        val syncButton = findViewById<FloatingActionButton>(R.id.syncButton)
        syncButton.setOnClickListener {
            if (isNetworkAvailable()) {
                var message: String
                var context = this
                CoroutineScope(Dispatchers.Main).launch {
                    message = dbHelper.syncData()
                    Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
                }
            }
            else {
                Toast.makeText(this, "No internet connection available!", Toast.LENGTH_SHORT).show()
            }
        }

        val button = findViewById<FloatingActionButton>(R.id.openPlantFormActivityButton)
        button.setOnClickListener{
            val InsertNewPlant = Intent(this, PlantInsertActivity::class.java)
            InsertNewPlant.putExtra("ownerId",
                getUserEmail()?.let { it1 -> dbHelper.getUserId(it1) })
            startActivity(InsertNewPlant)
        }
    }

    private fun isNetworkAvailable(): Boolean {
        val connectivityManager = getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
        val activeNetworkInfo = connectivityManager?.activeNetworkInfo
        return activeNetworkInfo != null && activeNetworkInfo.isConnected
    }


    /*private fun signOutAndStartSignInActivity() {
        mAuth.signOut()

        mGoogleSignInClient.signOut().addOnCompleteListener(this) {
            // Optional: Update UI or show a message to the user
            val intent = Intent(this, SignInActivity::class.java)
            startActivity(intent)
            finish()
        }
    }
    */

    override fun onBackPressed() {
        return
        super.onBackPressed()
    }
}
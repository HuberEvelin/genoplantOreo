package com.example.genoplantold
public class UserEmail {
    companion object {
        private var userEmail: String = ""
        private var userId: Int = 0


        fun setUserEmail(email: String) {
            userEmail = email
        }

        fun getUserEmail(): String {
            return userEmail
        }

        fun setUserId(id: Int) {
            userId = id
        }

        fun getUserId(): Int {
            return userId
        }

        fun clearUserEmail() {
            userEmail = ""
        }
    }
}

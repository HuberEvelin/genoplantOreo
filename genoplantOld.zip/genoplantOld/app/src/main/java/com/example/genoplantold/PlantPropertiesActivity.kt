package com.example.genoplantold

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import android.content.Intent
import android.widget.ImageButton
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.floatingactionbutton.FloatingActionButton

class PlantPropertiesActivity : AppCompatActivity() {
    private lateinit var dbHelper: DatabaseHelper
    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: PlantAdapter
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_plant_properties)

        val Title = findViewById<TextView>(R.id.plantNameEditText)
        Title.setText(intent.getStringExtra("Name"))
        val deletePlantButton=findViewById<FloatingActionButton>(R.id.deletePlantButton)
        val Id=intent.getIntExtra("Id",0)
        dbHelper = DatabaseHelper(this)
        deletePlantButton.setOnClickListener{
            val builder = AlertDialog.Builder(this)

            builder.setTitle("Alert")
            builder.setMessage("Are you sure you want to delete this plant?")

            // Pozitív gomb eseménykezelése
            builder.setPositiveButton("OK") { dialog, which ->
                dbHelper.deletePlantById(Id)
                val GoBackIntent = Intent(this, PlantNameActivity::class.java)
                startActivity(GoBackIntent)
                dialog.dismiss() // Az ablak bezárása
            }
            builder.setNegativeButton("Cancel") { dialog, which ->
                dialog.dismiss() // Az ablak bezárása
            }
            val alertDialog: AlertDialog = builder.create()
            alertDialog.show()
        }

        recyclerView = findViewById(R.id.allPlantProperties)
        val button = findViewById<FloatingActionButton>(R.id.openPlantFormActivityButton)
        button.setOnClickListener{
            val InsertNewPlant = Intent(this, PlantFormActivity::class.java)
            InsertNewPlant.putExtra("plantId", Id)
            InsertNewPlant.putExtra("insert", true)
            startActivity(InsertNewPlant)
        }
        val dataList =dbHelper.getAllFromPlantPropertiesById(Id.toString())
        val intent = Intent(this, PlantFormActivity::class.java)
        val goBackButton=findViewById<ImageButton>(R.id.backToNamesButton)
        goBackButton.setOnClickListener {
            onBackPressed()
        }

        adapter = PlantAdapter(object : OnPlantClickListener {
            override fun onPlantClick(position: Int) {
                val clickedPlant = dataList[position]
                val imagePath = dbHelper.getImagesByPlantFormId(clickedPlant.Id.toInt())[0]

                intent.putExtra("insert", false);
                intent.putExtra("Id", clickedPlant.Id)
                intent.putExtra("Name", clickedPlant.Name)
                intent.putExtra("Specie", clickedPlant.Specie)
                intent.putExtra("Indoor", clickedPlant.Indoor)
                intent.putExtra("Fertilized", clickedPlant.Fertilized)
                intent.putExtra("Soil", clickedPlant.Soil)
                intent.putExtra("AdditionalNote", clickedPlant.AdditionalNote)
                intent.putExtra("imagePath", imagePath)
                intent.putExtra("temperature", clickedPlant.Temperature)
                intent.putExtra("humidity", clickedPlant.Humidity)
                startActivity(intent)
            }
        })


        recyclerView.adapter = adapter
        recyclerView.layoutManager = LinearLayoutManager(this)
        adapter.submitList(dataList)
    }
    override fun onBackPressed() {
        val GoBackToNames: Intent = Intent(this, PlantNameActivity::class.java)
        startActivity(GoBackToNames)
        return
        super.onBackPressed()
    }
}
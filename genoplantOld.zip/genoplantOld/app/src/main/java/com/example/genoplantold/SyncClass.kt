package com.example.genoplantold

import com.example.genoplantold.UserEmail.Companion.getUserEmail
import org.json.JSONObject

class SyncClass {
    var email: String = getUserEmail()
    var plant: Plant = Plant("", "", "", "", true, "", "", true, "", 0, "",0,0)

    fun toJsonString(): JSONObject{
        val jsonObject = JSONObject()

        jsonObject.put("email", email)

        val plantObject = JSONObject()
        plantObject.put("name", plant.Name)
        plantObject.put("specie", plant.Specie)
        plantObject.put("date", plant.Date)
        plantObject.put("last_modified", plant.LastModified)
        plantObject.put("upload_date", plant.UploadDate)
        plantObject.put("indoor", plant.Indoor)
        plantObject.put("soil", plant.Soil)
        plantObject.put("fertilized", plant.Fertilized)
        plantObject.put("additional_note", plant.AdditionalNote)
        plantObject.put("owner_id", plant.OwnerId)

        jsonObject.put("plant", plantObject)

        return jsonObject
    }
}
package com.example.genoplantold

import android.text.InputFilter
import android.text.Spanned

class inputFilter : InputFilter {
    private val acceptedChars = "aábcdeéfghiíjklmnoóöőpqrstuúüűvwxyzAÁBCDEÉFGHIÍJKLMNOÓÖŐPQRSTUÚÜŰVWXYZ0123456789-() "

    override fun filter(
        source: CharSequence?,
        start: Int,
        end: Int,
        dest: Spanned?,
        dstart: Int,
        dend: Int
    ): CharSequence? {
        val filteredStringBuilder = StringBuilder()
        for (i in start until end) {
            val c = source?.get(i)

            if (c?.let { acceptedChars.contains(it) } == true) {
                filteredStringBuilder.append(c)
            } else {
                filteredStringBuilder.append('-')
            }
        }
        return filteredStringBuilder.toString()
    }
}
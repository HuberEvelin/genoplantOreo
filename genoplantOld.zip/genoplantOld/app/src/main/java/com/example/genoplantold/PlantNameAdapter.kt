package com.example.genoplantold

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class PlantNameAdapter(private val listener: OnPlantClickListener) : RecyclerView.Adapter<PlantNameAdapter.PlantNameViewHolder>() {

    private var plantList = ArrayList<Plant>()

    inner class PlantNameViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView), View.OnClickListener {
        val nameTextView: TextView = itemView.findViewById(R.id.nameTextView)

        init {
            itemView.setOnClickListener(this)
        }
        override fun onClick(v: View?) {
            val position = adapterPosition
            if (position != RecyclerView.NO_POSITION) {
                listener.onPlantClick(position)
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PlantNameViewHolder {
        var itemView : View
        if(plantList[0].Id.equals("-1")){
            itemView = LayoutInflater.from(parent.context).inflate(R.layout.empty_item_list, parent, false)
        }
        else{
            itemView = LayoutInflater.from(parent.context).inflate(R.layout.plant_item, parent, false)
        }
        return PlantNameViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: PlantNameViewHolder, position: Int) {
        val currentPlant = plantList[position]
        holder.nameTextView.text = currentPlant.Name
    }


    override fun getItemCount(): Int {
        return plantList.size
    }

    fun submitList(list: ArrayList<Plant>) {
        plantList = list
        notifyDataSetChanged()
    }
}

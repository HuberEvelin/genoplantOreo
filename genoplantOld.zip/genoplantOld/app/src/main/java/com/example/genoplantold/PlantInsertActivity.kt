package com.example.genoplantold

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.DatePicker
import android.widget.EditText
import android.widget.ImageButton
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class PlantInsertActivity : AppCompatActivity() {
    private lateinit var dbHelper: DatabaseHelper
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_plant_insert)

        val GoBackIntent = Intent(this, PlantNameActivity::class.java)
        val goBackButton=findViewById<ImageButton>(R.id.backToNames)
        val infoButton=findViewById<Button>(R.id.infoButton)
        val Name = findViewById<EditText>(R.id.edittext_plant_name)
        Name.filters = arrayOf(inputFilter())
        val Species = findViewById<EditText>(R.id.edittext_plant_species)
        Species.filters = arrayOf(inputFilter())
        val saveButton = findViewById<Button>(R.id.saveToDataBase)
        infoButton.setOnClickListener {
            val builder = AlertDialog.Builder(this)
            builder.setTitle("Instructions")
            builder.setMessage("Fill out the fields to add a new plant, a new form, or to edit an existing one! The name, age, and plant species fields are mandatory to fill out. If you want to assign a new form to an existing plant, type the name of the selected plant in the name field. You can not use any special characters besides - and ().")

            builder.setPositiveButton("OK") { dialog, which ->
                dialog.dismiss()
            }
            val dialog: AlertDialog = builder.create()
            dialog.show()
        }
        datePickerInitialization()
        goBackButton.setOnClickListener {
            onBackPressed()
        }
        dbHelper = DatabaseHelper(this)
        saveButton.setOnClickListener{
            if(Name.text.toString()=="" || Species.text.toString()=="" || Name.text.toString().contains('\n') || Species.text.toString().contains('\n')){
                val builder = AlertDialog.Builder(this)

                builder.setTitle("Alert")
                builder.setMessage("You must fill the name and the specie field correctly!")

                // Pozitív gomb eseménykezelése
                builder.setPositiveButton("OK") { dialog, which ->
                    dialog.dismiss()
                }

                val dialog: AlertDialog = builder.create()
                dialog.show()
            }
            else{
                if (dbHelper.checkPlantExists(UserEmail.getUserId(), Name.text.toString()) == 1) {
                    dbHelper.insertPlant(
                        Name.text.toString(),
                        Species.text.toString(),
                        datePickerFormat(),
                        0
                        //intent.getIntExtra("ownerId", 0)
                    )
                    startActivity(GoBackIntent)
                } else {
                    val builder = AlertDialog.Builder(this)

                    builder.setTitle("Alert")
                    builder.setMessage("A plant already exists with this name. Please use another.")

                    builder.setPositiveButton("OK") { dialog, which ->
                        dialog.dismiss()
                    }

                    val dialog: AlertDialog = builder.create()
                    dialog.show()
                }
            }
        }
    }
    override fun onBackPressed() {
        val intent = Intent(this, PlantNameActivity::class.java)
        val ageLabel = findViewById<TextView>(R.id.ageInDays).text.toString()
        val name=findViewById<EditText>(R.id.edittext_plant_name).text.toString()
        val specie=findViewById<EditText>(R.id.edittext_plant_species).text.toString()
        val currentCalendar = Calendar.getInstance()
        val currentYear = currentCalendar.get(Calendar.YEAR)
        val currentMonth = currentCalendar.get(Calendar.MONTH)
        val currentDay = currentCalendar.get(Calendar.DAY_OF_MONTH)

        if(name.equals("") && specie.equals("") && (ageLabel.equals("Age in days:") || ageLabel.equals("Age in days: 0")))
        {
            startActivity(intent)
        }
        else{
            val builder = AlertDialog.Builder(this)

            builder.setTitle("Alert")
            builder.setMessage("Are you sure you want to go back?"+'\n' + "The unsaved data will be lost!")

            // Pozitív gomb eseménykezelése
            builder.setPositiveButton("OK") { dialog, which ->
                startActivity(intent)
                dialog.dismiss() // Az ablak bezárása
            }
            builder.setNegativeButton("Cancel"){ dialog, which ->
                dialog.dismiss() // Az ablak bezárása
            }

            // Ablak létrehozása és megjelenítése
            val dialog: AlertDialog = builder.create()
            dialog.show()
        }
        return
        super.onBackPressed()
    }

    private fun datePickerFormat() : String {
        val calendar = Calendar.getInstance()
        val datePicker=findViewById<DatePicker>(R.id.plantDatePicker)
        val year = datePicker.year
        val month = datePicker.month
        val dayOfMonth = datePicker.dayOfMonth

        calendar.set(year, month, dayOfMonth)

        val selectedDateFormatted: String = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(calendar.time)
        return selectedDateFormatted
    }
    fun onDateSet(view: DatePicker?, year: Int, month: Int, dayOfMonth: Int) {
        plantAge(datePickerFormat())
    }
    fun plantAge(birthday: String) {
        val currentDate = Calendar.getInstance().timeInMillis / 1000

        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        val date = sdf.parse(birthday)
        val dateUnixTimestamp = date.time / 1000

        val differenceInDays = (currentDate - dateUnixTimestamp) / (60 * 60 * 24)

        val ageLabel = findViewById<TextView>(R.id.ageInDays)
        ageLabel.setText("Age in days: " + differenceInDays.toString())
    }
    fun datePickerInitialization() {
        val currentCalendar = Calendar.getInstance()
        val currentYear = currentCalendar.get(Calendar.YEAR)
        val currentMonth = currentCalendar.get(Calendar.MONTH)
        val currentDay = currentCalendar.get(Calendar.DAY_OF_MONTH)
        val datePicker = findViewById<DatePicker>(R.id.plantDatePicker)
        datePicker.maxDate = currentCalendar.timeInMillis
        datePicker.init(
            currentYear,
            currentMonth,
            currentDay
        ) { view, year, month, dayOfMonth ->
            // Az adat megváltozott, itt hívódik meg az OnDateChangedListener
            onDateSet(view, year, month, dayOfMonth)
        }
    }
}
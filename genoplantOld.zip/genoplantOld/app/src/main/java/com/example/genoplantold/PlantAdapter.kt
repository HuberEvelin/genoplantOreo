package com.example.genoplantold

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.RecyclerView


class PlantAdapter(private val listener: OnPlantClickListener) : RecyclerView.Adapter<PlantAdapter.PlantViewHolder>(){
    private var plantList = ArrayList<Plant>()

    inner class PlantViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView), View.OnClickListener {
        val nameTextView: TextView = itemView.findViewById(R.id.nameTextView)

        init {
            itemView.setOnClickListener(this)
        }
        override fun onClick(v: View?) {
            val position = adapterPosition
            /*if (position != RecyclerView.NO_POSITION) {
                listener.onPlantClick(position)
            }*/
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PlantViewHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(R.layout.plant_property_item, parent, false)
        return PlantViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: PlantViewHolder, position: Int) {
        val currentPlant = plantList[position]
        holder.nameTextView.text=currentPlant.UploadDate
    }

    override fun getItemCount(): Int {
        return plantList.size
    }

    fun submitList(list: ArrayList<Plant>) {
        plantList = list
        /*notifyDataSetChanged()*/
    }
}